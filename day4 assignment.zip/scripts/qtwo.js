/*Question 2:
Destructure the following object*/

const student={
    name:"Hellsinki",
    age:24,
    projects:{
        diceGame:"Two player dice game using JavaScript"
    }
}
const{name,age,projects}=student;
console.log(name);
console.log(age);
console.log(projects);