let Sales=prompt("Enter the total sale");
if(Sales<5000){
let comm=Sales*0.02;
console.log("Total commisssion earned by employee:",comm)
}
else if(Sales>5000 && Sales<=10000){
    let comm=(5000*0.02)+(5000*0.05)+((Sales-10000)*0.07)
    console.log("Total commisssion earned by employee:",comm)
}
else if(Sales>10001 && Sales<=20000){
    let comm=(5000*0.02)+(5000*0.05)+(10000*0.07)+((Sales-20000)*0.1)
    console.log("Total commisssion earned by employee:",comm)
}
else if(Sales>20000){
    let comm=Sales*10;
    console.log("Total commisssion earned by employee:",comm)
}
    